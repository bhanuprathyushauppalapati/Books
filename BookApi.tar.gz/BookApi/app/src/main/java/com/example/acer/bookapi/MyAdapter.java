package com.example.acer.bookapi;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewInfo> {
    Context ct;
    ArrayList<Pojo> list;

    public MyAdapter(MainActivity mainActivity, ArrayList<Pojo> list){
    ct=mainActivity;
    this.list=list;

    }

    @NonNull
    @Override
    public MyAdapter.MyViewInfo onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
      View v= LayoutInflater.from(ct).inflate(R.layout.row,parent,false);
        return new MyViewInfo(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyAdapter.MyViewInfo holder, int position) {

        holder.tv.setText(list.get(position).getTitle());
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class MyViewInfo extends RecyclerView.ViewHolder {

        TextView tv;

        public MyViewInfo(View itemView) {
            super(itemView);
            tv=itemView.findViewById(R.id.tv);
        }
    }
}
