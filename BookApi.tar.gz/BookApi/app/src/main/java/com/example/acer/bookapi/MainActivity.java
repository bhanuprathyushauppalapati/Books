package com.example.acer.bookapi;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.Loader;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.JsonReader;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<String> {
    TextView title, author;
    EditText editText;
    Button button;
    ImageView imageView;

    ArrayList<Pojo> list;
    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //title=findViewById(R.id.title_text);
        //author=findViewById(R.id.author_text);
        editText = findViewById(R.id.et1);
        button = findViewById(R.id.button);
        imageView = findViewById(R.id.image);
        recyclerView = findViewById(R.id.rv);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }

    public void search(View view) {
        String book = editText.getText().toString();
        Bundle b = new Bundle();
        b.putString("key", book);
        getSupportLoaderManager().initLoader(1, b, MainActivity.this);

    }


    @NonNull
    @Override
    public Loader<String> onCreateLoader(int id, @Nullable Bundle args) {
        String data = args.getString("key");
        return new MyAsc(this, data);
    }

    @Override
    public void onLoadFinished(@NonNull Loader<String> loader, String data) {
        Toast.makeText(this, data, Toast.LENGTH_SHORT).show();

        list=new ArrayList<Pojo>();
        try {
            Toast.makeText(this, ""+data, Toast.LENGTH_SHORT).show();
            JSONObject object = new JSONObject(data);
            JSONArray array = object.getJSONArray("items");

            String title = null;



            for (int i = 0; i < array.length(); i++) {
                JSONObject object1 = array.getJSONObject(i);
                JSONObject object2 = object1.getJSONObject("volumeInfo");
                title = object2.getString("title");
                Pojo p=new Pojo(title);
                list.add(p);

               /* // builder.append(title);
                author = object2.getString("authors");
                //builder.append(author);
                JSONObject image = object2.getJSONObject("imagelinks");
                imageLinks = image.getString("thumbnail");*/
               }

            //title.setText(builder.toString());
            //author.setText(book.getTitle());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        MyAdapter adapter = new MyAdapter(this, list);
        recyclerView.setAdapter(adapter);

    }

    @Override
    public void onLoaderReset(@NonNull Loader<String> loader) {

    }
}
